/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** Sending the signals to enemy.
*/

#include "./include/my.h"

void char_to_int(char *correct_attack)
{
    int i;
    int j;

    j = (correct_attack[0] - 'A') * 2;
    i = (correct_attack[1] - '0') - 1;
    dc_to_bn(i, j);
}

void dc_to_bn(int i, int j)
{
    int binary_array[9] = {0, 0, 0, 0, 0, 0, 0, 0, -1};
    int iter = 7;

    while (j > 0) {
        binary_array[iter] = j % 2;
        iter = iter - 1; 
        j = j / 2;
    }
    iter = 3;
    while (i > 0) {
        binary_array[iter] = i % 2;
        iter = iter - 1;
        i = i / 2;
    }
    send_attack(binary_array);
}

void send_attack(int *binary_array)
{
    int l = 0;

    while (l < 8) {
        if (binary_array[l] == 1) {
            kill(my_strt.enemy, SIGUSR1);
        } else {
            kill(my_strt.enemy, SIGUSR2);
        }
        l = l + 1;
    }
}