/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** Error function.
*/

#include "./include/my.h"

int error(void)
{
    return 84;
}