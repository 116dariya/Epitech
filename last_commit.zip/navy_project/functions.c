/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** The most used functions.
*/

#include "./include/my.h"

int len_of_string(char *string)
{
    int l = 0;

    while(string[l]){
        l = l + 1;
    }
    return(l);
}

void write_char(char c)
{
    write(1, &c, 1);
}

char *copy_string(char *input, char *output)
{
    int l = 0;

    if (len_of_string(input) == len_of_string(output)) {
        while(input[l]) {
            output[l] = input[l];
            l = l + 1;
        }
        return output;
    }
    return NULL;
}

int power(int a, int b)
{
    int num = 1;
    while (b > 0) {
        num = num * a;
        b = b - 1;
    }
    return num;
}

int len_of_array(int *array)
{
    int l = 0;
    while (array[l] >= 0) {
        l = l + 1;
    }
    return(l);
}