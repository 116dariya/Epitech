/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** The game file.
*/

#include "./include/my.h"

void game(bool num, char **map1, char **map2)
{
    int count = 0;

    while (count <= 14) {
        if (num == true) {
            char_to_int(write_attack());
        } else {
            take_attack(map1, map2);
        }
        count = 15;
    }
}

char *write_attack(void)
{
    char *attack = malloc(2 * sizeof(char));
    write(1, "\nattack: ", 9);
    scanf("%s", attack);
    while( check_attack(attack) == false){
        scanf("%s", attack);
    }
    return attack;
}

bool check_attack(char *attack)
{
    if (len_of_string(attack) != 2) {
        write(1, "wrong position\nattack: ", 23);
        return false;
    }
    if (attack[0] < 'A' || attack[0] > 'H' ||
        attack[1] < '1' || attack[1] > '8') {
        write(1, "wrong position\nattack: ", 23);
        return false;
    }
    return true;
}