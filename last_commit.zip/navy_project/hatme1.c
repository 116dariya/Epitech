/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** The handler filer for player 1.
*/

#include "./include/my.h"

void hatme1(int sigg, siginfo_t *sin, void* useless)
{
    int l = 0;

    if(sigg == SIGUSR1){
        kill(sin->si_pid, SIGUSR2);
        my_strt.enemy = sin->si_pid;
    }
    else if(sigg == SIGUSR2){
        l = l + 1;
    }
    else{
        error();
    }
}
