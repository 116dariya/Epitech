/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** Present the enemy's map.
*/

#include "./include/my.h"

void hatme3(int a)
{
    if ( a == 1) {
        kill(my_strt.enemy, SIGUSR1);
    } else if ( a == 0 ) {
        kill(my_strt.enemy, SIGUSR2);
    }
}