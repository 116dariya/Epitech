/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** Putting the boats to board.
*/

#include "./include/my.h"

void put_all_boats(char const * const file_path, char ***map)
{
    read_from_file(file_path, map);
    show_map(*map);
}

void read_from_file(char const * const file_path, char ***map)
{
    char inp[50];
    int fd = open(file_path, O_RDONLY);	

    if (fd > 0) {
        while (read(fd, inp, 8) > 0) {
            converter(inp, map);
        }
        close(fd);
    } else {
        error();
    }
}

void converter(char *arr, char ***map)
{
    int new_arr[6];
    char boat_size = arr[0];
    new_arr[0] = ((int)arr[0]) - 48;
    new_arr[1] = (int)arr[2] - 'A';
    new_arr[2] = (int)arr[3] - '0';
    new_arr[3] = (int)arr[5] - 'A';
    new_arr[4] = (int)arr[6] - '0';

    put_one_boat(new_arr, map, boat_size);
}

void put_one_boat(int *arr, char ***map, char size)
{
    if (arr[1] == arr[3]) {
        for (int j = arr[2]; j <= arr[4]; j++) {
            (*map)[j-1][arr[1]*2] = size;
        }
    } else if (arr[2] == arr[4]) {
        for (int i = arr[1] * 2; i <= arr[3] * 2; i+= 2) {
            (*map)[arr[2]-1][i] = size;
        }
    } else {
        error();
    }
}