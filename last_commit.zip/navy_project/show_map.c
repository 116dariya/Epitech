/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** Presenting my map.
*/

#include "./include/my.h"

void show_map(char **carte)
{
    write(1, "my positions:\n", 14);
    write(1, " |A B C D E F G H\n", 18);
    write(1, "-+---------------\n", 18);
    for (int i = 0; i < 8; ++i) {
        write_number(i+1);
        write_char('|');
        for (int j = 0; j < 15; ++j) {
            if ( j % 2 == 1) {
                write(1, " ", 1);
                //write_char(' ');
            } else {
               // write(1, carte[i][j], 1);
                write_char(carte[i][j]);
            }
        }
        write(1, "\n", 1);
    }
    write(1, "\n", 1);
}