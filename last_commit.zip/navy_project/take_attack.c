/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** Recieving the attack.
*/

#include "./include/my.h"
#include <errno.h>
#include <string.h>

bool take_attack(char **map1, char **map2)
{
	int *posatt  = malloc(2 * sizeof(int));
	int i = 0;
/*
    while (i<7) {
        printf("OK\n");
        if(signal(SIGUSR1, handler_one)){
            printf("Receiving 1\n");
            my_strt.message[i] = 1;
        } else if (signal(SIGUSR2, handler_zero)) {
            printf("Receiving 2\n");
            my_strt.message[i] = 0;
        }
        i = i + 1;
        usleep(10000);
    }
*/
	struct sigaction sigme;
	sigme.sa_handler = &hatme2; //fuction pointers
	sigme.sa_flags = 0;
	sigemptyset(&sigme.sa_mask);
	sigaction(SIGUSR1, &sigme, NULL);
	sigaction(SIGUSR2, &sigme, NULL);
	pause();
    
	while (i < 7) {
		if (usleep(20000) != 0){
			strerror(errno);
		}
		i = i + 1;
	}

	posatt = bn_to_dc(my_strt.message);
	result(hit_or_miss(posatt, map1), map2, posatt);
	return false;
}

int *bn_to_dc(int *binary_array)
{
    int *cordinates = malloc(2 * sizeof(int));
    int i, j, x, y = 0;
    int iter = 7;

    while ( i < 4) {
        x = x + (power(2, i) * binary_array[iter]);
        i = i + 1;
        iter = iter - 1;
    }
    cordinates[1] = x;
    while ( j < 4 ) {
        y = y + (power(2, i) * binary_array[iter]);
        j = j + 1;
        iter = iter - 1;	
    }
    cordinates[0] = y;
    //printf("%d % d\n", cordinates[0], cordinates[1]);
    return cordinates;
}

bool hit_or_miss(int *posatt, char **map1)
{
    int i = posatt[0];
    int j = posatt[1];

    if (map1[i][j] != ' ' || map1[i][j] != '.'
        || map1[i][j] != 'x' || map1[i][j] != 'o') {
        write(1, "hit\n", 4);
        send_hit();
        return true;
    } else { 
        write(1, "missed\n", 7);
        send_miss();
        return false;
    }
    return false;
}

void result(bool flag, char **map2, int *posatt)
{	
	if (flag == true) { //hit
		map2[posatt[0]][posatt[1]] = 'x';
	} else {
		map2[posatt[0]][posatt[1]] = 'o';
	}
}