/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** Checking the arguments before using.
*/

#include "./include/my.h"

bool check_args(unsigned int argc, char **argv)
{
    if (argc == 2) {
        return read_check_file(argv[1]);
    } else if (argc == 3) {
        return read_check_file(argv[2]);
    }
    return false;
}

bool read_check_file (char const * const file_path)
{
    char inp[50];
    int fd = open(file_path, O_RDONLY);
    bool stop = true;

    if (fd > 0) {
        while (stop == true && read(fd, inp, 8) > 0) {
            stop = check_line(inp);
        }
        close(fd);
    } else {
        return false;
    }
    return stop;
}

bool check_line(char *inp)
{
    if (inp[0] < '2' || inp[0] > '5') {
        return false;
    }
    if (inp[2] < 'A' || inp[2] > 'H') {
        return false;
    }
    if (inp[3] < '1' || inp[3] > '8') {
        return false;
    }
    if (inp[5] < 'A' || inp[5] > 'H') {
        return false;
    }
    if (inp[6] < '1' || inp[6] > '8') {
        return false;
    }
    return check_diagonal_boat(inp);
}

bool check_diagonal_boat(char *inp)
{
    if(inp[2] != inp[5] && inp[3] != inp[6]) {
        return false;
    }
    return true;
}