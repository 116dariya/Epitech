/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** Connection players.
*/

#include "./include/my.h"

void connection(unsigned int argc, char **argv)
{
    int pid = getpid();

    if (argc == 2) {
        write(1, "my_pid: ", 8);
        write_number(pid);
        write(1, "\nwaiting for enemy connection...\n\n", 34);
        connection_first();	
    } else if (argc == 3){
        write(1, "my_pid: ", 8);
        write_number(pid);
        my_strt.enemy = my_atoi(argv[1]);
        kill(my_strt.enemy, SIGUSR1);
        connection_second();
        write(1, "\nsuccessfully connected\n\n", 25);
    }
}

void connection_first(void)
{
    struct sigaction sigme;
    sigme.sa_sigaction = &hatme1;
    sigme.sa_flags = SA_SIGINFO;
    if ((sigaction(SIGUSR1,&sigme,NULL)) == 0) {
        pause();
        write(1, "enemy connected\n\n", 17);
    } else {
        error();
    }
}

void connection_second(void)
{
    struct sigaction sigme;
    sigme.sa_sigaction = &hatme1; 
    sigme.sa_flags = SA_SIGINFO;
    if((sigaction(SIGUSR2,&sigme,NULL)) == 0){
        usleep(20000);
    } else {
        error();
    }
}