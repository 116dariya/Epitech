/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** The main file for Navy.
*/

#include "./include/my.h"

int main(int argc, char **argv)
{
    char **map1 = NULL;
    char **map2 = NULL;
    
    if (check_args(argc, argv) == false) {
        return 84;
    }
    map1 = init_map();
    map2 = init_map();
    if (map1 == NULL || map2 == NULL)
        return 84;
    connection(argc,argv);
    put_all_boats(argc == 2 ? argv[1] : argv[2], &map1);
    show_enemy_map(map2);
    game(argc == 2 ? true : false, map1, map2);
    return 0;
}