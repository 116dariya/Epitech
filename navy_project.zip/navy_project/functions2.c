/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** Sending the signals to enemy.
*/

#include "./include/my.h"

void write_number(int i)
{
    if (i >= 10) {
        write_number(i/10);
    }
    i = i % 10 + '0';
    write_char(i);
}

int my_atoi(char *string)
{
    int n = 0;

    while (*string >= '0' && *string <= '9') {
        n *= 10;
        n += *string++;
        n -= '0';
    }
    return n;
}