#include "./include/my.h"

void handler_one(int signum)
{
    printf("Receiving function 1\n");
}

void handler_zero(int signum)
{
    printf("Receiving function 0\n");
}