/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** The handler filer for player 2.
*/

#include "./include/my.h"

void hatme2(int sigg)
{
    int l = 0;

    if (sigg == SIGUSR1) {
        my_strt.message[l] = 1;
    }
    else if (sigg == SIGUSR2) {
        my_strt.message[l] = 0;
    }
    l = l + 1;
}