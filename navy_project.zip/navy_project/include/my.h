/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** The h file for project.
*/

#ifndef MY_H
#define MY_H
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <stdbool.h>

typedef struct global_s {
	pid_t enemy;
	int message[9];
} global_t;

global_t my_strt;

bool check_args(unsigned int argc, char **argv);
bool read_check_file (char const * const file_bus);
bool check_line(char *inp);
bool check_diagonal_boat(char *inp);
char **init_map(void);
void put_all_boats(char const * const file_path, char ***map);
void read_from_file(char const * const file_path, char ***map);
void converter(char *arr, char ***map);
void put_one_boat(int *arr, char ***map, char size);
int error(void);
void show_map(char **map);
void connection(unsigned int argc, char **argv);
void connection_first(void);
void connection_second(void);
void hatme1(int sigg, siginfo_t *sin, void *useless);
void show_enemy_map(char **carte);
int len_of_string(char *string);
void game(bool num, char **map1, char **map2);
char *write_attack(void);
bool check_attack(char *attack);
void write_char(char c);
char *copy_string(char *input, char *output);
void char_to_int(char *correct_attack);
void dc_to_bn(int i, int j);
void send_attack(int *binary_array);
void hatme2(int sigg);
bool hit_or_miss(int *posatt, char **map1);
int len_of_array(int *array);
void send_hit(void);
void send_miss(void);
int power(int a, int b);
int *bn_to_dc(int *binary_array);
void result(bool flag, char **map2, int *posatt);
bool take_attack(char **map1, char **map2);
void write_number(int i);
int my_atoi(char *s);

void handler_one(int signum);

void handler_zero(int signum);

#endif