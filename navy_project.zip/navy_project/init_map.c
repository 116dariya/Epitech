/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** Initializing the game board.
*/

#include "./include/my.h"

char **init_map(void)
{
    char **map = malloc(8 * sizeof(char*));

    if (map == NULL)
        return NULL;
    for (int i = 0; i < 8; ++i) {
        map[i] = malloc(15*sizeof(char));
        if (map[i] == NULL)
            return NULL;
        for (int j = 0; j < 15; ++j) {
            map[i][j] = '.';
        }
    }
    return map;
}
