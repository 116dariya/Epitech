/*
** EPITECH PROJECT, 2019
** Navy.
** File description:
** Sending the hit or miss.
*/

#include "./include/my.h"

void send_hit(void)
{
    kill(my_strt.enemy, SIGUSR1);
}

void send_miss(void)
{
    kill(my_strt.enemy, SIGUSR2);
}